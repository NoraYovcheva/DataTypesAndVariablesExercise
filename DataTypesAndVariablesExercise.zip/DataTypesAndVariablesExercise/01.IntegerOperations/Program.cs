﻿using System;

namespace _01.IntegerOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            const double puzzelPrice = 2.60;
            const double dollPrice = 3;
            const double bearPrice = 4.10;
            const double minionPrice = 8.20;
            const double truckPrice = 2;

            double priceForExcursion = double.Parse(Console.ReadLine());
            int countOfPuzzel = int.Parse(Console.ReadLine());
            int countOfDoll = int.Parse(Console.ReadLine());
            int countOfBear = int.Parse(Console.ReadLine());
            int countOfMinion = int.Parse(Console.ReadLine());
            int countOfTruck = int.Parse(Console.ReadLine());

            double countOfToys = countOfPuzzel + countOfDoll + countOfBear + countOfMinion + countOfTruck;
            double sum = countOfPuzzel * puzzelPrice + countOfDoll * dollPrice + countOfBear * bearPrice + countOfMinion * minionPrice + countOfTruck * truckPrice;
            
            double discount = 0;
            if (countOfToys >= 50)
            {
                discount = sum * 0.25;
            }
            double finalSum = sum - discount;
            double discountForRent = finalSum * 0.10;
            double rent = finalSum - discountForRent;
            double moneyMade = finalSum - rent;
            if (priceForExcursion > moneyMade)
            {
                double moneyneeded = priceForExcursion - moneyMade;
                Console.WriteLine($"Yes! {moneyneeded:f2} lv left.");
            }
            else
            {
                double moneyLeft = moneyMade - priceForExcursion;
                Console.WriteLine($"Not enough money! {moneyLeft:f2} lv needed.");
            }
        }
    }
}
